<footer>
<strong>© THE ARTBOX</strong> - <em>Tous droits réservés</em>
</footer>